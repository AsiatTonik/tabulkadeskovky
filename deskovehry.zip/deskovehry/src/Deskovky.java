import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Deskovky extends JFrame {
    private JButton dalsiButton;
    private JButton predchoziButton;
    private JCheckBox zakoupenoCheckBox;
    private JTextArea textArea1;
    private JPanel panel1;
    private JSlider slider1;
    private int indexSeznamu = 0;

    public Form() {
        vypln();
        predchoziButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                indexSeznamu--;
                vypln();
            }
        });
        dalsiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                indexSeznamu++;
                vypln();
            }
        });
    }

    public void vypln(){
        CteniZeSouboru cteniZeSouboru = new CteniZeSouboru();
        cteniZeSouboru.vypis();
        List<Deskovky> seznam = cteniZeSouboru.getListGamesek();
        Deskovky deskovky = seznam.get(indexSeznamu);
        textArea1.setText(deskovky.getNazev());
        slider1.setValue(deskovky.getOblibenost());
        zakoupenoCheckBox.setSelected(deskovky.isKoupeno());
    }

    public static void main(String[] args) {
        Deskovky h = new Deskovky();
        h.setContentPane(h.panel1);
        h.setVisible(true);
        h.pack();
        h.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}